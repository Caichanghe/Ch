package Niao;

public abstract class Niao {
    abstract void fly();
    abstract void sing();
}
