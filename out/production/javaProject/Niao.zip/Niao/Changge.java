package Niao;

public interface Changge {
    void changge();

}
