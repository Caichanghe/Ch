package Zhenghou;

public class Changfangxing extends Tuxinglei{
    public static void main(String[] args) {
        Changfangxing changfangxing=new Changfangxing();
        changfangxing.chang=20;
        changfangxing.kuan=25;
        changfangxing.mj(changfangxing);
    }
}
