package Zhenghou;

public class Yuanxing extends Tuxinglei{
    public static void main(String[] args) {
        Yuanxing yuanxing=new Yuanxing();
        yuanxing.r=6;
        yuanxing.mj(yuanxing);
    }
}
